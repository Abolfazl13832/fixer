def get_rates(api_key):
    print("gfjg")