from setuptools import setup

setup(name="fixer",
      version="1",
      author="Abolfazl Alipour",
      author_email="alypwr573@gmail.com",
      url="https://github.com/Abolfazl13832/fixer.git",
      packages=['fixer'])